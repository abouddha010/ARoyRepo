package testSearch; 
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.Select;

public class FlightSearchTest {

	public static void main(String[] args) {
		 // System Property for Chrome Driver   
        System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\chromedriver.exe");  
          
         // Instantiate a ChromeDriver class.     
        WebDriver driver=new ChromeDriver();  
          
          // Launch Travel Web site  
        driver.navigate().to("http://jt-dev.azurewebsites.net/#/SignUp");  
          
         //Maximize the browser  
          driver.manage().window().maximize();  
          
          //Actions to perform
          //Click on Language Drop Down
          driver.findElement(By.xpath("//*[@id='language']/div[1]/span/span[2]")).click();
          
         // Validation of Drop down "English" and "Dutch" options       
          List<WebElement> options = driver.findElements(By.xpath("//*[@class='ui-select-choices-group']/div/a/div"));  
          for(WebElement we:options)  
          { 
        	  String abc = we.getText();
        	  System.out.println("language is "+abc);
               if (abc.equals("English")){
                 System.out.println("English Language is matched");
               }
               else if (abc.equals("Dutch")){
                   System.out.println("Dutch Language is matched");
                 }
               else 
            	   System.out.println("Languages are Not Matched");
             }
           
          //Entering Name
          driver.findElement(By.xpath("//*[@id='name']")).sendKeys("�mita Roy");
          
          //Entering Organization Name
          driver.findElement(By.xpath("//*[@id='orgName']")).sendKeys("Amita");
          
          //Entering Email ID
          driver.findElement(By.xpath("//*[@id='singUpEmail']")).sendKeys("abouddha010@gmail.com");
          
          //Agree with Terms check box check
          driver.findElement(By.xpath("//*[@id='content']/div/div[3]/div/section/div[1]/form/fieldset/div[4]/label/span")).click();
          
          //Get started button click
          driver.findElement(By.xpath("//*[@id='content']/div/div[3]/div/section/div[1]/form/fieldset/div[5]")).click();
          System.out.println("Check you email received from JabaTalksDevelopmemt & click on confirm your account to confirm the email ID");
	}

}
